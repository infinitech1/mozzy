<?php
require 'vendor/autoload.php';
use Twilio\Rest\Client;

$accountSid = 'ACe1c1cdfb1d146b56116e38631ed06080';
$authToken = '82bbf59917c5623f2ac259d9acfb1968';

$client = new Client($accountSid, $authToken);

$recipient = $_POST['recipient'];
$message = $_POST['message'];

try {
    $message = $client->messages->create(
        $recipient, // Recipient's phone number
        [
            'from' => '+12296296087', // Your Twilio phone number
            'body' => $message,
        ]
    );

    echo "SMS sent to $recipient with SID: " . $message->sid;
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
