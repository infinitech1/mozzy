<?php
$servername = "sql8.freemysqlhosting.net";
$username = " sql8657865";
$password = "XZkrY74uWa";
$dbname = " sql8657865"; // Your database name
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
