<?php
session_start();
require_once("db.php");

if (isset($_POST['addStudent'])) {
    $studentId = $_POST['addStudentId'];
    $firstName = $_POST['addFirstName'];
    $lastName = $_POST['addLastName'];
    $email = $_POST['addEmail'];
    $class = $_POST['addClass'];
    $address = $_POST['addAddress'];
    $parent = $_POST['addParent'];
    $dateOfBirth = $_POST['addDateOfBirth'];
  

    // Handle profile picture upload
    $profilePicture = ''; // Initialize as empty

    if (isset($_FILES['addProfilePicture']) && $_FILES['addProfilePicture']['error'] === 0) {
        // Define the directory to store uploaded profile pictures
        $uploadDir = 'profile_pictures/';

        // Generate a unique filename for the profile picture
        $profilePicture = $uploadDir . uniqid() . '_' . $_FILES['addProfilePicture']['name'];

        // Move the uploaded profile picture to the designated directory
        if (move_uploaded_file($_FILES['addProfilePicture']['tmp_name'], $profilePicture)) {
            // Profile picture uploaded successfully
        } else {
            // Handle profile picture upload error
            $profilePicture = ''; // Reset to empty
        }
    }

    // Insert data into the "Learners" table
  // Insert the admin registration data into the database
        $sql = "INSERT INTO Learners (StudentId, FirstName, LastName,Sex,Class, Address, Parent, Date_of_birth,ProfilePhoto) VALUES (?, ?, ?, ?, ?, ?, ?,  ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error in SQL statement: " . $conn->error);
    }

    $stmt->bind_param("sssssssss", $studentId, $firstName, $lastName, $email, $class, $address, $parent, $dateOfBirth,  $profilePicture);

    if ($stmt->execute()) {
        // Data inserted successfully
        session_start();
        $_SESSION['success_message'] = "Student added successfully!";
        header("Location: admin.php");
        exit();
    } else {
        // Error in inserting data
        session_start();
        $_SESSION['error_message'] = "Error: " . $stmt->error;
        header("Location: admin.php");
        exit();
    }
}

?>

