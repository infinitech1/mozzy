<!DOCTYPE html>
<html>
<head>
    <title>School Management System</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
</head>
<body>
    <?php include('includes/header.php'); ?>

    <h1>Welcome to GODS FAVOUR PRIMARY SCHOOL-KABALE</h1>

    <ul>
        <li><a href="students.php">Students</a></li>
        <li><a href="teachers/attendance.php">Teachers</a></li>
        <li><a href="results.php">Results</a></li>
        <li><a href="reports.php">Reports</a></li>
          <li><a href="admin.php">Admin</a></li>
           <li><a href="teachers/login.php">Login</a></li>
        <li><a href="notification/index.html">Notifications and SMS</a></li>
    </ul>

    <?php include('includes/footer.php'); ?>
</body>
</html>
