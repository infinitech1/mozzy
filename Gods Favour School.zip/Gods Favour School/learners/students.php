
<!DOCTYPE html>
<html>
<head>
    <title>Student Management</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
</head>
<body>
    <?php include('includes/header.php'); ?>

    <h2>Student Management</h2>

    <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>ID</th>
            <th>Parent Name</th>
            <th>Address</th>
            <th>Sex</th>
            <th>Phone Number</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$row['first_name']}</td>";
            echo "<td>{$row['last_name']}</td>";
            echo "<td>{$row['student_id']}</td>";
            echo "<td>{$row['parent_name']}</td>";
            echo "<td>{$row['address']}</td>";
            echo "<td>{$row['sex']}</td>";
            echo "<td>{$row['phone_number']}</td>";
            echo "</tr>";
        }
        ?>
    </table>

    <?php include('includes/footer.php'); ?>
</body>
</html>
