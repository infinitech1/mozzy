<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Teacher</title>
    <link rel="stylesheet" type="text/css" href="styles/admins.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Include your CSS styling for the page here -->
</head>
<body>
    <div class="main">
        <h2>Add Teacher</h2><a href="admin.php"><h2>Back Home</a></h2>
    </div>
    <div class="tabcontent2">
        <div class="content">
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Process the form data to add the teacher to your system.
                // You can implement this part based on your specific requirements.
                // Example: Insert teacher data into your database.

                // Simulate teacher addition success
                $teacherAdded = true;
            }
            ?>
            <?php if (isset($teacherAdded) && $teacherAdded): ?>
                <div class="message success">
                    <i class="fa fa-check"></i> Teacher added successfully.
                </div>
                <script>
                    setTimeout(function() {
                        var successMessage = document.querySelector('.message.success');
                        successMessage.style.display = 'none';
                    }, 3000); // Hide the message after 3 seconds
                </script>
            <?php endif; ?>
            <div class="content">
            <form method="post" action="add_teacher.php">
    <label for="teacherName">Teacher Name<span class="required"><font color="red">*</font></span></label>
    <input type="text" id="teacherName" name="teacherName" required>

    <label for="teacherEmail">Teacher Email<span class="required"><font color="red">*</font></span></label>
    <input type="email" id="teacherEmail" name="teacherEmail" required>

    <!-- Add more input fields for teacher details as needed -->

    <input type="submit" name="addTeacher" value="Add Teacher" class="btn1">
</form>
            </form>
        </div>
        </div>
    </div>
</body>
</html>
