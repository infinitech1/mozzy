<!-- includes/header.php -->
<header>
    <h1>School Management System</h1>
</header>