
<!-- includes/footer.php -->
<footer>
    <p>&copy; 2023 GODS FAVOUR PRIMARY SCHOOL-KABALE</p>
</footer>
