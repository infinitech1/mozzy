
        // Get modal elements and buttons
        var addStudentModal = document.getElementById("addStudentModal");
        var openModalBtn = document.getElementById("openModalBtn");
        var closeModalBtn = document.getElementById("closeModalBtn");

        // Open the modal when the "Add Student" button is clicked
        openModalBtn.addEventListener("click", function () {
            addStudentModal.style.display = "block";
        });

        // Close the modal when the close button is clicked
        closeModalBtn.addEventListener("click", function () {
            addStudentModal.style.display = "none";
        });

        // Close the modal if the user clicks outside the modal content
        window.addEventListener("click", function (event) {
            if (event.target === addStudentModal) {
                addStudentModal.style.display = "none";
            }
        });
    
        // Function to update the profile picture preview
function updateProfilePicturePreview(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();

        reader.onload = function (e) {
            document.getElementById('profilePicturePreview').src = e.target.result;
        };

        reader.readAsDataURL(input.files[0]);
    }
}

// Attach an event listener to the profile picture input
document.getElementById('addProfilePicture').addEventListener('change', function () {
    updateProfilePicturePreview(this);
});

// Function to remove the profile picture
document.getElementById('removeProfilePicture').addEventListener('click', function () {
    document.getElementById('profilePicturePreview').src = 'female_avatar.jpg';
    document.getElementById('addProfilePicture').value = ''; // Clear the file input
});

