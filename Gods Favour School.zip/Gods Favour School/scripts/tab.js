function openOption(evt, optionName) {
  var i, tabcontent, tablinks;

  // Hide all tab content sections
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Deactivate all tab buttons
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].classList.remove("active");
  }

  // Show the selected tab content and mark the button as active
  document.getElementById(optionName).style.display = "block";
  evt.currentTarget.classList.add("active");
}
// for clock
function updateDateTime() {
    const clockElement = document.getElementById("clock");
    const dateElement = document.getElementById("date");

    // Create a new Date object to get the current date and time
    const now = new Date();

    // Format the time including seconds (e.g., "10:30:45 AM")
    const timeString = now.toLocaleTimeString(undefined, {
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        hour12: true
    });

   
    const dateString = now.toLocaleDateString(undefined, {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    });

    // Update the clock and date elements with the formatted time and date
    clockElement.textContent = timeString;
    dateElement.textContent = dateString;
}

// Call the updateDateTime function to display the initial date and time
updateDateTime();

// Update the date and time every second (1000 milliseconds)
setInterval(updateDateTime, 1000);


