<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GOD'S FAVOUR</title>
 <link rel="stylesheet" type="text/css" href="styles/admins.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

 <link rel="stylesheet" type="text/css" href="notification/style.css">

</head>
<body>
     <div class="main">
        <h2>Welcome!
        <br> A quick summary of your school !</h2>
        <div id="dateTimeDisplay">
  <div id="date"></div>
   <div id="clock"></div>
</div>
        </div>
     <div id="bonne chance;" class="tabcontent2">
        
        <div class="chart">
<?php
require_once("db.php");

// Query to count the number of learners
$countSql = "SELECT COUNT(*) as totalLearners FROM Learners";
$countResult = $conn->query($countSql);

// Check if the query was successful
if ($countResult) {
    $row = $countResult->fetch_assoc();
    $totalLearners = $row['totalLearners'];
} else {
    $totalLearners = 0; // Default to 0 if there was an error
}

?>    
        <center><p>  <i class="fa fa-users" ></i>&nbsp;&nbsp;&nbsp;<?php echo $totalLearners; ?> learners</p>
        <h4>School Enrollment</h4></center>
</div>
        <div class="chart-teacher">
  
        <center><p> <i class="fa fa-users"></i>&nbsp;&nbsp;&nbsp;<?php echo $totalLearners; ?> </p>
        <h4>Teaching Staff</h4></center>
</div>
<br>
<br>
<div class="chart">
    <canvas id="learnersChart" width="400" height="200"></canvas>

    <script>
        // Get the total number of learners from your PHP code
        var totalLearners = <?php echo $totalLearners; ?>;

        // Define the data for the chart
        var data = {
            labels: ["Total Learners"],
            datasets: [
                {
                    label: "Total Learners",
                    backgroundColor: "rgba(75, 192, 192, 0.2)",
                    borderColor: "rgba(75, 192, 192, 1)",
                    borderWidth: 1,
                    data: [totalLearners],
                },
            ],
        };

        // Define chart options
        var options = {
            scales: {
                y: {
                    beginAtZero: true,
                },
            },
        };

        // Get the canvas element and create the chart
        var ctx = document.getElementById("learnersChart").getContext("2d");
        var learnersChart = new Chart(ctx, {
            type: "bar",
            data: data,
            options: options,
        });

        // Update the total learners value in the HTML
        document.getElementById("totalLearners").textContent =
            totalLearners + " learners";
    </script>
    </div>
    <br>
    <br>
</div>
<br>
<div id="errorMessageModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close" onclick="closeErrorMessageModal()">&times;</span>
        <p id="errorMessageText"></p>
    </div>
</div>
<br>
<!-- Success Message -->
<?php if (isset($_SESSION['success_message'])): ?>
    <div class="message success">
        <i class="fa fa-check"></i>
        <?php echo $_SESSION['success_message']; ?>

    </div>
    <script>
        setTimeout(function() {
            var successMessage = document.querySelector('.message.success');
            successMessage.style.display = 'none';
        }, 4000);
    </script>
<?php unset($_SESSION['success_message']); endif; ?>

<!-- Error Message -->
<?php if (isset($_SESSION['error_message'])): ?>
    <div class="message error">
        <i class="fa fa-exclamation-circle"></i>
        <?php echo $_SESSION['error_message']; ?>
        <span class="close" onclick="closeMessage(this)">&times;</span>
    </div>
    <script>
        setTimeout(function() {
            var errorMessage = document.querySelector('.message.error');
            errorMessage.style.display = 'none';
        }, 2000);
    </script>
<?php unset($_SESSION['error_message']); endif; ?>




<br>
<div></div>
<div class="tab">
    <center>
    <h4>GOD'S FAVOUR PRIMARY SCHOOL</h4>
    <h4>School Management System</h4>
</center>
    <br>
    <center><img src="img_avatar.png" alt="Profile Picture" class="profile-picture"></center>
    <br>
<button class="tablinks" onclick="openOption(event, 'London')"> <i class="fa fa-home"></i>&nbsp;&nbsp;Home</button>
<br>
<button class="tablinks" onclick="openOption(event, 'Paris')"> <i class="fa fa-users"></i>&nbsp;&nbsp;Add Learners</button>
<!-- Add similar onclick attributes for other tabs -->

  <br>
  <button class="tablinks" onclick ="openOption(event, 'Tokyo')">
    <i class="fa fa-users"></i>&nbsp;&nbsp;Human Resource</button>

  <br>
  <button class="tablinks" onclick ="openOption(event, 'China')"> <i class="fa fa-file"></i>&nbsp;&nbsp;Make Announcement</button>
  <br>
  <button class="tablinks" onclick="openOption(event, 'Students')"><i class="fa fa-book"></i>&nbsp;&nbsp;View Learners</button>
  <br>
</div>

<div id="London" class="tabcontent">
  <a href="index.php"><i class="fa fa-home">&nbsp;&nbsp;Click  me to go home</i></a>
</div>

<div id="Paris" class="tabcontent">

<button id="openModalBtn" class="btn1">Add New Student</button>

<div id="addStudentModal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeModalBtn">&times;</span>
            <style>
    /* CSS to make the profile picture circular */
    .profile-picture {
        border-radius: 50%;
        width: 150px; /* Set the desired width and height for the circular image */
        height: 150px;
    }
</style>
<h2>Add New Student</h2>
<br>
<br>
<h4>GOD'S FAVOUR PRIMARY SCHOOL ONLINE LEARNERS REGISTRATION PORTAL</h4>
<br>
<form method="post" action="functions.php" enctype="multipart/form-data" id="studentForm">
   
    <hr/>
    <br>
     <img id="profilePicturePreview" src="img_avatar.png" alt="Profile Picture" class="profile-picture">
          <br>
        <br>
<div class="form-row">
    <div class="form-column">
        <label for="addProfilePicture" class="custom-file-upload">
    <i class="fa fa-cloud-upload"></i> Upload Student Photo
</label>
<input type="file" id="addProfilePicture" name="addProfilePicture" accept="image/*" required  style="display: none;">

        <label for="addStudentId">Student ID:</label>
        <input type="text" id="addStudentId" name="addStudentId" required>

        <label for="addFirstName">First Name:</label>
        <input type="text" id="addFirstName" name="addFirstName" required>

        <label for="addLastName">Last Name:</label>
        <input type="text" id="addLastName" name="addLastName" required>

<label for="addEmail">Sex:</label>
        <input type="text" id="addEmail" name="addEmail" required>
</select>
         <label for="addClass">Class:</label>
        <input type="text" id="addClass" name="addClass" required>


    </div>
    <div class="form-column">
        <label for="addAddress">Address:</label>
        <input type="text" id="addAddress" name="addAddress" required>
        <label for="addParent">Parent Details:</label>
        <input type="text" id="addParent" name="addParent" required>

        <label for="addDateOfBirth">Date of Birth:</label>
        <input type="date" id="addDateOfBirth" name="addDateOfBirth" required>
       
        <label for="addPassword">Password:</label>
        <input type="password" id="addPassword" name="addPassword" required maxlength="10"
            pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{10,}"
            title="Must contain at least one number and one uppercase and lowercase letter, and at least 10 characters">
    </div>
</div>
    <br>
    <center><input type="submit" name="addStudent" value="Add Student" class="btn1"></center>
    <br>
    <hr/>
</form>
</body>

        </div>
    </div>    
    </div>
</div>       
  <script type="text/javascript" src="scripts/add.js"></script>
    </html>
</div>

<div id="Tokyo" class="tabcontent">
  <h3>Human Resource</h3>
  <p>Manage Teachers</p>
  <div class="dropdown">
    <button onclick="toggleTeachersDropdown()" class="dropbtn">
      Teacher Actions <i class="fa fa-caret-down"></i>
    </button>
    <div id="teachersDropdown" class="dropdown-content">
      <a href="teachers/view_teachers.php">View Teachers</a>
      <a href="add_teachers.php">Add Teacher</a>
    </div>
  </div>
</div>
<script type="text/javascript">
    // for drop down
function toggleTeachersDropdown() {
  var dropdown = document.getElementById("teachersDropdown");
  if (dropdown.style.display === "block") {
    dropdown.style.display = "none";
  } else {
    dropdown.style.display = "block";
  }
}
</script>
<div id="Students" class="tabcontent">
    <h3>Recently Added Learners</h3>

    <?php

require_once("db.php");

// Fetch all student records for the summary table
$summarySql = "SELECT * FROM Learners";
$summaryResult = $conn->query($summarySql);

?>
<table border="1"  id="myTable">
    <thead>
        <tr>
            <th>Student ID</th>
            <th>Learner</th>
            <th>Sex</th>
            <th>Address</th>
            <th>Parent Details</th>
            <th>D.O.B</th>
            <th>Class</th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $summaryResult->fetch_assoc()): ?>
            <tr class="student-row">
                <td><?php echo $row['StudentId']; ?></td>
                <td><?php echo $row['FirstName']; ?> <?php echo $row['LastName']; ?></td>
                <td><?php echo $row['Sex']; ?></td>
                <td><?php echo $row['Address']; ?></td>
                <td><?php echo $row['Parent']; ?></td>
                <td><?php echo $row['Date_of_birth']; ?></td>
                <td><?php echo $row['Class']; ?></td>
                <td>
                    <form method="post" action="admin_dashboard.php">
                        <input type="hidden" name="deleteStudentId" value="<?php echo $row['StudentId']; ?>">
                        <input type="submit"   name="deleteStudent" value="Remove" class="btn">
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

</div>

<div id="China" class="tabcontent">
 <div class="container">
        <h1>GOD'S FAVOR PRIMARY SCHOOL</h1>
        <h1>SMS Notification Centre</h1>
        <form action="notification/send_sms.php" method="POST">
            <label for="recipient">Recipient's Phone Number:</label>
            <input type="tel" name="recipient" id="recipient" required>
            <label for="message">Message:</label>
            <textarea name="message" id="message" required></textarea>
            <input type="submit" value="Send SMS">
        </form>
    </div>
</div>
<div class="clearfix"></div>

<script type="text/javascript" src="scripts/tab.js"></script>  
</body>
</html> 
<!-------navi--->
