<?php

$host = 'sql8.freemysqlhosting.net';
$username = ' sql8657865';
$password = 'XZkrY74uWa';
$database = "sql8657865";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Query the attendance records
$query = "SELECT teachers.name, attendance.attendance_time
          FROM attendance
          INNER JOIN teachers ON attendance.teacher_id = teachers.id";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="attendance.csv');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Teacher Name', 'Attendance Time']);

    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [$row['name'], $row['attendance_time']]);
    }

    fclose($output);
} else {
    echo "No attendance records found.";
}
