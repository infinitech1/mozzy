<!DOCTYPE html>
<html>
<head>
    <title>Facial Recognition</title>
</head>
<body>
    <h1>Facial Recognition</h1>
    <div>
        <video id="video" width="640" height="480" autoplay></video>
        <button id="capture">Capture</button>
    </div>
    <canvas id="canvas" width="640" height="480" style="display: none;"></canvas>
    <div id="result"></div>
    <script src="face-api.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
