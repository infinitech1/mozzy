<?php
// Database connection
$servername = "sql8.freemysqlhosting.net";
$username = " sql8657865";
$password = "XZkrY74uWa";
$dbname = " sql8657865"; // Your database name
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['teacher_name'])) {
        $teacherName = $_POST['teacher_name'];

        // Insert attendance record into the database
        $sql = "INSERT INTO teachers (name) VALUES ('$teacherName')";
        if ($conn->query($sql) === TRUE) {
            echo "Thanks for attending today.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Teacher name is not set in the POST request.";
    }
}

$conn->close();
?>
