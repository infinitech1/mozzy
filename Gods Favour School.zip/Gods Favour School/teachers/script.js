function signAttendance() {
    // Get the teacher's name (you may need to adjust this part)
    var teacherName = prompt("Please enter your Full names here:");
    if (teacherName) {
        var formData = new FormData();
        formData.append("teacher_name", teacherName);

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "save_attendance.php", true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                alert(xhr.responseText);
            }
        };
        xhr.send(formData);
    }
}
// time
function checkTimeAndSignAttendance() {
    var currentTime = new Date();
    var signTime = new Date();
    signTime.setHours(8, 0, 0); // Set the desired sign-in time to 8:00 AM

    if (currentTime <= signTime) {
        // It's before or at 8:00 AM, so you can sign attendance
        // Perform the sign-in process here
        signAttendance();
    } else {
        // It's after 8:00 AM, display the modal alert
        openModal();
    }
}

// Display the modal
function showModal() {
  var modal = document.getElementById("myModal");
  modal.style.display = "block";
}

// Close the modal
function closeModal() {
  var modal = document.getElementById("myModal");
  modal.style.display = "none";
}

// Function to check if it's after 8:00 AM
function checkTimeAndSignAttendance() {
  var currentTime = new Date();
  var hours = currentTime.getHours();
  var minutes = currentTime.getMinutes();

  if (hours < 8 || (hours === 8 && minutes > 0)) {
    // It's past 8:00 AM
    showModal();
  } else {
    // Sign attendance
    signAttendance();
  }
}

// Add an event listener to the "Sign Attendance" button
var signAttendanceBtn = document.getElementById("signAttendanceBtn");
signAttendanceBtn.addEventListener("click", checkTimeAndSignAttendance);

// You can add AJAX code here to load and display the attendance list
