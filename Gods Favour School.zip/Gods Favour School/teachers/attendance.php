<!DOCTYPE html>
<html>
<head>
    <title>Teachers Attendance Tracking</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <!-- Attendance system and modal code here -->
    <div class="container">
        <h1>Teachers Attendance Tracking System</h1>

        <button id="signAttendanceBtn" onclick="checkTimeAndSignAttendance()">Sign Attendance</button>

        <div id="attendanceList">
            <!-- Attendance records will be displayed here -->
        </div>

        <h1><a href="download_attendance.php" id="downloadAttendanceBtn" download>Download Attendance</a></h1>
 
    <!-- Modal code here -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <p>You cannot sign in after 8:00 AM.</p>
        </div>
    </div>
   </div>

    <script src="script.js"></script>
</body>
</html>
